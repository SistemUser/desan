/**
 * Desan Konveyör & Mekanik İmalat
 * Core Functional Engine (Vanilla JS)
 * Handles: SPA Routing, Belt Configurator, Roller Tolerance Engine, Cart Math & Proforma
 */

import './index.css';

(function () {
  'use strict';

  // ==========================================
  // STATE MANAGEMENT & LOCAL STORAGE
  // ==========================================
  const DEFAULT_CART = [
    {
      id: 'c1',
      title: 'EP 400/3 4+2 Antistatik Kauçuk Bant',
      desc: 'Genişlik: 800mm, Kalınlık: 10mm, Aşınma Dayanımlı',
      qty: 150,
      unit: 'm',
      unitPrice: 1240,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJhwVnmEkAv7dIdgZxkefDEhnA7l_wQqq01Tv9xIZIQ2fz_SLfah6mJpUXWrY4D_qiK3UEUcsB4NOZZcTdaJTklC69pPLMP-tvd_dDnEMwwKtPcyyBWeQRyYdwfF4fNum5jAdYaO-tTtit7COu_xxZ8gT_rurWZhfREPg658iwLK5XoIyTiGeLny-Yk0pvyNMbJ2ifhj5x8H7_I8l3-uTUBo8Aa-7-bzAwnE_HaAbrmZxZ8pPpbUbT'
    },
    {
      id: 'c2',
      title: 'Taşıyıcı Rulo İstasyonu – Üçlü',
      desc: 'Çap: Ø89mm, Boru: 315mm, Şase Genişliği: 800mm',
      qty: 45,
      unit: 'ad',
      unitPrice: 850,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBDXU98gVd288k6wB9YuZoN3Le3og3wl6oNnuHmH_8WLxRvmNK9Oh38GcNcnXjsEiEGx7jFSrFVnHSsYE9qyuuY2YDYYWZeKcESfG5tUsm87nVeMqr_VYTNH19UEFJB5VmASI_9pLJxdWdLfrAnJjyaO95ZwPPHidli-UhWrx4XAHqCdqOzm5jSPcxz_cRMygoCpy0tZissaGqOFT9c7Nnvj2nNM7yFpZ1YChw9IQ7pBimJYDgGM_3g'
    },
    {
      id: 'c3',
      title: 'UCP 210 Yataklı Rulman',
      desc: 'Mil Çapı: 50mm, Pik Döküm Gövde, Ağır Hizmet',
      qty: 12,
      unit: 'ad',
      unitPrice: 1120,
      image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA_Ktx4OFsRmW-hNuz3khP8M5BfXI_tPKqs3V4uA4KJteGJ0LY4CFPh8SwSse8-slw5qgG-2GJVKWIVANMgvUvYv0VnjQ5DmXnJDFlwnOIRjVS9OaytYxsACV12yNyHOQ0kwkQD0TJvpvCFHF1SzFk6lN7FyCksZyQQZLlhMDfdO2I7r-j7nhlU1FJ61jIZ33Erz_jwyui8FzjHAxulJC2J5-UDX5Kw4tMm3lxYpF4S4jNFQRupoVcv'
    }
  ];

  const STORAGE_KEY = 'desan_b2b_cart_v1';

  function loadCartFromStorage() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return DEFAULT_CART;
  }

  function saveCartToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state.cart));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }

  const state = {
    currency: 'TL', // 'TL' or 'USD'
    usdRate: 36.5,
    cart: loadCartFromStorage()
  };

  // Utility: Currency Formatter
  function formatMoney(amount, showSymbol = true) {
    let val = amount;
    let symbol = '₺';
    if (state.currency === 'USD') {
      val = amount / state.usdRate;
      symbol = '$';
    }
    const formatted = val.toLocaleString('tr-TR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    return showSymbol ? `${symbol} ${formatted}` : formatted;
  }

  // Toast Notification
  function showToast(message, type = 'success') {
    let container = document.getElementById('desan-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'desan-toast-container';
      container.className = 'fixed bottom-20 right-6 z-50 flex flex-col gap-2 pointer-events-none';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `px-4 py-3 rounded-lg shadow-lg font-mono text-xs flex items-center gap-2.5 transition-all duration-300 transform translate-y-2 opacity-0 pointer-events-auto ${
      type === 'error'
        ? 'bg-rose-600 text-white'
        : 'bg-slate-900 text-white border border-slate-700'
    }`;
    toast.innerHTML = `
      <span class="material-symbols-outlined text-[18px] ${type === 'error' ? 'text-rose-200' : 'text-emerald-400'}">
        ${type === 'error' ? 'error' : 'check_circle'}
      </span>
      <span>${message}</span>
    `;
    container.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
      toast.classList.add('translate-y-0', 'opacity-100');
    });

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // ==========================================
  // 1. SPA ROUTER & NAVIGATION
  // ==========================================
  function initRouter() {
    const pages = document.querySelectorAll('[data-page]');
    const desktopNavLinks = document.querySelectorAll('#desktop-nav [data-nav-target]');
    const mobileNavLinks = document.querySelectorAll('#mobile-nav [data-nav-target]');

    function navigate(targetId) {
      if (!targetId) targetId = 'home';

      const actualPage = targetId === 'tambur' ? 'rulo' : targetId;

      // Hide all pages
      pages.forEach(page => {
        if (page.getAttribute('data-page') === actualPage) {
          page.classList.remove('hidden');
        } else {
          page.classList.add('hidden');
        }
      });

      // Update Desktop Nav Links
      desktopNavLinks.forEach(link => {
        const linkTarget = link.getAttribute('data-nav-target');
        const isActive = (linkTarget === targetId) || (linkTarget === 'rulo' && targetId === 'tambur');
        if (isActive) {
          link.className = 'text-[#0284c7] font-bold border-b-2 border-[#0284c7] py-2 transition-all shrink-0';
        } else {
          link.className = 'text-slate-800 hover:text-[#0284c7] py-2 transition-colors shrink-0 font-medium';
        }
      });

      // Update Mobile Nav Links
      mobileNavLinks.forEach(link => {
        const linkTarget = link.getAttribute('data-nav-target');
        const isActive = (linkTarget === targetId) || (linkTarget === 'rulo' && targetId === 'tambur');
        if (isActive) {
          link.className = 'mobile-nav-item flex items-center gap-3 px-3.5 py-3 rounded-lg bg-sky-50 text-[#0284c7] font-bold transition-all';
        } else {
          link.className = 'mobile-nav-item flex items-center gap-3 px-3.5 py-3 rounded-lg text-slate-700 hover:bg-slate-50 hover:text-[#0284c7] font-medium transition-all';
        }
      });

      // Special check for cart button in header
      const cartBtn = document.getElementById('header-cart-btn');
      if (cartBtn) {
        if (targetId === 'sepet') {
          cartBtn.classList.add('ring-2', 'ring-[#0284c7]', 'bg-sky-100');
        } else {
          cartBtn.classList.remove('ring-2', 'ring-[#0284c7]', 'bg-sky-100');
        }
      }

      // If switching to rulo or tambur, trigger corresponding tab
      if (targetId === 'tambur') {
        window.dispatchEvent(new CustomEvent('app:set-rulo-mode', { detail: { tambur: true } }));
      } else if (targetId === 'rulo') {
        window.dispatchEvent(new CustomEvent('app:set-rulo-mode', { detail: { tambur: false } }));
      }

      window.scrollTo({ top: 0, behavior: 'instant' });
    }

    // Attach click listeners to all router links
    document.addEventListener('click', e => {
      const target = e.target.closest('[data-nav-target], a[href^="#"]');
      if (!target) return;

      let navTarget = target.getAttribute('data-nav-target');
      if (!navTarget && target.getAttribute('href')) {
        const href = target.getAttribute('href');
        if (href.startsWith('#') && href.length > 1) {
          navTarget = href.substring(1);
        }
      }

      if (navTarget) {
        e.preventDefault();
        window.location.hash = navTarget;
        navigate(navTarget);
      }
    });

    // Handle initial route or hashchange
    function handleHash() {
      const hash = window.location.hash.replace('#', '') || 'home';
      navigate(hash);
    }

    window.addEventListener('hashchange', handleHash);
    handleHash();
  }

  // ==========================================
  // MOBILE NAVIGATION DRAWER CONTROLLER
  // ==========================================
  function initMobileMenu() {
    const toggleBtn = document.getElementById('mobile-menu-toggle');
    const closeBtn = document.getElementById('mobile-menu-close');
    const drawer = document.getElementById('mobile-menu-drawer');
    const backdrop = document.getElementById('mobile-menu-backdrop');
    const icon = document.getElementById('mobile-menu-icon');

    if (!toggleBtn || !drawer || !backdrop) return;

    let isOpen = false;

    function openMenu() {
      isOpen = true;
      drawer.classList.remove('translate-x-full');
      backdrop.classList.remove('opacity-0', 'pointer-events-none');
      backdrop.classList.add('opacity-100');
      document.body.classList.add('overflow-hidden');
      if (icon) icon.textContent = 'close';
    }

    function closeMenu() {
      isOpen = false;
      drawer.classList.add('translate-x-full');
      backdrop.classList.add('opacity-0', 'pointer-events-none');
      backdrop.classList.remove('opacity-100');
      document.body.classList.remove('overflow-hidden');
      if (icon) icon.textContent = 'menu';
    }

    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (isOpen) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeMenu();
      });
    }

    backdrop.addEventListener('click', closeMenu);

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && isOpen) {
        closeMenu();
      }
    });

    // Close automatically when clicking any navigation link inside drawer
    drawer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        closeMenu();
      });
    });
  }

  // ==========================================
  // 2. QUICK HOME CALCULATOR
  // ==========================================
  function initHomeCalculator() {
    const beltSelect = document.getElementById('calc-belt');
    const widthInput = document.getElementById('calc-width');
    const lengthInput = document.getElementById('calc-length');
    const priceDisplay = document.getElementById('calc-price');
    const addBtn = document.getElementById('btn-home-calc-add');

    function updatePrice() {
      if (!beltSelect || !widthInput || !lengthInput || !priceDisplay) return;
      const basePerMeter = parseFloat(beltSelect.value) || 1250;
      const width = parseFloat(widthInput.value) || 650;
      const length = parseFloat(lengthInput.value) || 25;
      const jointRadios = document.getElementsByName('joint');
      let jointCost = 0;
      for (const radio of jointRadios) {
        if (radio.checked && radio.value === 'endless') {
          jointCost = 1450;
        }
      }

      const widthFactor = width / 1000;
      const total = Math.round(basePerMeter * widthFactor * length + jointCost);
      priceDisplay.textContent = formatMoney(total);
    }

    if (beltSelect && widthInput && lengthInput && priceDisplay) {
      beltSelect.addEventListener('change', updatePrice);
      widthInput.addEventListener('input', updatePrice);
      lengthInput.addEventListener('input', updatePrice);
      document.querySelectorAll('input[name="joint"]').forEach(el => {
        el.addEventListener('change', updatePrice);
      });
      updatePrice();
    }

    if (addBtn) {
      addBtn.addEventListener('click', () => {
        const beltName = beltSelect.options[beltSelect.selectedIndex].text;
        const width = widthInput.value;
        const length = lengthInput.value;
        const basePerMeter = parseFloat(beltSelect.value) || 1250;
        const jointEndless = document.querySelector('input[name="joint"][value="endless"]')?.checked;
        const jointCost = jointEndless ? 1450 : 0;
        const total = Math.round(basePerMeter * (parseFloat(width) / 1000) * parseFloat(length) + jointCost);

        state.cart.push({
          id: 'c_' + Date.now(),
          title: beltName.split('(')[0].trim(),
          desc: `Genişlik: ${width}mm, Uzunluk: ${length}m, ${jointEndless ? 'Sonsuz Vulkanize' : 'Açık Uçlu'}`,
          qty: 1,
          unit: 'ad',
          unitPrice: total,
          image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJhwVnmEkAv7dIdgZxkefDEhnA7l_wQqq01Tv9xIZIQ2fz_SLfah6mJpUXWrY4D_qiK3UEUcsB4NOZZcTdaJTklC69pPLMP-tvd_dDnEMwwKtPcyyBWeQRyYdwfF4fNum5jAdYaO-tTtit7COu_xxZ8gT_rurWZhfREPg658iwLK5XoIyTiGeLny-Yk0pvyNMbJ2ifhj5x8H7_I8l3-uTUBo8Aa-7-bzAwnE_HaAbrmZxZ8pPpbUbT'
        });

        renderCart();
        showToast('Konveyör Bandı teklif sepetinize eklendi!');
        window.location.hash = 'sepet';
      });
    }
  }

  // ==========================================
  // 3. BANT HESAPLAMA MOTORU (ÖZEL KESİM SAYFASI)
  // ==========================================
  function initBantCalculator() {
    const widthInput = document.getElementById('width-input');
    const lengthInput = document.getElementById('length-input');
    const metersBadge = document.getElementById('meters-badge');
    const tensileSelect = document.getElementById('tensile-strength');
    const coatingSelect = document.getElementById('coating-thickness');
    const skuDisplay = document.getElementById('sku-display');
    const specMaterial = document.getElementById('spec-material');
    const specThickness = document.getElementById('spec-thickness');
    const specDimensions = document.getElementById('spec-dimensions');
    const specTermin = document.getElementById('spec-termin');
    const specUnitPrice = document.getElementById('spec-unit-price');
    const specTotalPrice = document.getElementById('spec-total-price');
    const svgLengthText = document.getElementById('svg-length-text');
    const svgWidthText = document.getElementById('svg-width-text');
    const svgSpliceLabel = document.getElementById('svg-splice-label');
    const addCartBtn = document.getElementById('btn-bant-add-cart');

    if (!widthInput || !lengthInput) return;

    let currentMaterial = 'RUB';
    let currentBaseRate = 4250;
    let currentSplice = 'SP';
    let currentSpliceLabel = 'SICAK EK';
    let currentTermin = 'Vulkanize / 24-48 Saat İkitelli Sevk';

    function updateCalculation() {
      const w = parseFloat(widthInput.value) || 650;
      const l = parseFloat(lengthInput.value) || 12500;
      const meters = l / 1000;
      const tensileVal = tensileSelect?.value || 'EP400';
      const thicknessVal = coatingSelect?.value || '4+2 mm';

      // Dynamic badges & specs
      if (metersBadge) metersBadge.textContent = meters.toFixed(2) + ' Metre';
      if (specDimensions) specDimensions.textContent = meters.toFixed(2) + ' m × ' + w + ' mm';
      if (specThickness) specThickness.textContent = thicknessVal;

      // SVG updates
      if (svgLengthText) svgLengthText.textContent = 'L: ' + Math.round(l) + ' mm';
      if (svgWidthText) svgWidthText.textContent = 'W: ' + Math.round(w) + ' mm';
      if (svgSpliceLabel) svgSpliceLabel.textContent = currentSpliceLabel;

      // Spec material text
      if (tensileSelect && specMaterial) {
        const optText = tensileSelect.options[tensileSelect.selectedIndex].text;
        specMaterial.textContent = optText.split(' ')[0] + ' (3 Kat Bez)';
      }
      if (specTermin) specTermin.textContent = currentTermin;

      // SKU format: DSN-[MAT]-[TYPE]-W[width]-L[length]-[SPLICE]
      const sku = 'DSN-' + currentMaterial + '-' + tensileVal + '-W' + Math.round(w) + '-L' + Math.round(l) + '-' + currentSplice;
      if (skuDisplay) skuDisplay.textContent = sku;

      // Price calculation
      const unitMeterPrice = currentBaseRate * (w / 650);
      const totalPrice = unitMeterPrice * meters;

      if (specUnitPrice) {
        specUnitPrice.innerHTML = `${formatMoney(unitMeterPrice)} <span class="text-[11px] text-slate-500 font-normal">/ m</span>`;
      }
      if (specTotalPrice) {
        specTotalPrice.textContent = formatMoney(totalPrice);
      }
    }

    // Material Radio Selection
    const materialOptions = document.querySelectorAll('.material-option');
    materialOptions.forEach(card => {
      card.addEventListener('click', function () {
        materialOptions.forEach(c => {
          c.classList.remove('bg-sky-50/60', 'border-2', 'border-[#0284C7]', 'shadow-sm');
          c.classList.add('bg-white', 'border', 'border-slate-200');
          const icon = c.querySelector('.check-icon');
          if (icon) {
            icon.textContent = 'radio_button_unchecked';
            icon.classList.remove('text-[#0284C7]');
            icon.classList.add('text-slate-300');
          }
        });

        card.classList.remove('bg-white', 'border-slate-200');
        card.classList.add('bg-sky-50/60', 'border-2', 'border-[#0284C7]', 'shadow-sm');
        const radio = card.querySelector('input[type="radio"]');
        if (radio) {
          radio.checked = true;
          currentMaterial = radio.value;
          currentBaseRate = parseFloat(radio.dataset.rate) || 4250;
        }

        const icon = card.querySelector('.check-icon');
        if (icon) {
          icon.textContent = 'check_circle';
          icon.classList.remove('text-slate-300');
          icon.classList.add('text-[#0284C7]');
        }

        updateCalculation();
      });
    });

    // Quick Width buttons
    const quickBtns = document.querySelectorAll('.quick-w-btn');
    quickBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        quickBtns.forEach(b => {
          b.classList.remove('bg-[#0284C7]', 'text-white', 'font-bold');
          b.classList.add('bg-slate-100', 'text-slate-700');
        });
        btn.classList.remove('bg-slate-100', 'text-slate-700');
        btn.classList.add('bg-[#0284C7]', 'text-white', 'font-bold');

        widthInput.value = btn.dataset.val;
        updateCalculation();
      });
    });

    // Splice Selection
    const spliceBtns = document.querySelectorAll('.splice-btn');
    spliceBtns.forEach(btn => {
      btn.addEventListener('click', function () {
        spliceBtns.forEach(b => {
          b.classList.remove('border-2', 'border-[#0284C7]', 'bg-sky-50/50');
          b.classList.add('border-slate-200', 'bg-white');
          const spIcon = b.querySelector('.splice-icon');
          if (spIcon) {
            spIcon.textContent = 'radio_button_unchecked';
            spIcon.classList.replace('text-[#0284C7]', 'text-slate-300');
          }
        });

        btn.classList.remove('border-slate-200', 'bg-white');
        btn.classList.add('border-2', 'border-[#0284C7]', 'bg-sky-50/50');
        const spIcon = btn.querySelector('.splice-icon');
        if (spIcon) {
          spIcon.textContent = 'check_circle';
          spIcon.classList.replace('text-slate-300', 'text-[#0284C7]');
        }

        currentSplice = btn.dataset.splice || 'SP';
        currentSpliceLabel = btn.dataset.splicelabel || 'SICAK EK';
        currentTermin = btn.dataset.termin || 'Vulkanize / 24-48 Saat İkitelli Sevk';
        updateCalculation();
      });
    });

    widthInput.addEventListener('input', () => {
      quickBtns.forEach(b => {
        if (b.dataset.val === widthInput.value) {
          b.classList.remove('bg-slate-100', 'text-slate-700');
          b.classList.add('bg-[#0284C7]', 'text-white', 'font-bold');
        } else {
          b.classList.remove('bg-[#0284C7]', 'text-white', 'font-bold');
          b.classList.add('bg-slate-100', 'text-slate-700');
        }
      });
      updateCalculation();
    });

    lengthInput.addEventListener('input', updateCalculation);
    tensileSelect?.addEventListener('change', updateCalculation);
    coatingSelect?.addEventListener('change', updateCalculation);

    updateCalculation();

    if (addCartBtn) {
      addCartBtn.addEventListener('click', () => {
        const w = widthInput.value;
        const l = lengthInput.value;
        const sku = skuDisplay ? skuDisplay.textContent : 'DSN-RUB';
        const meters = (parseFloat(l) / 1000).toFixed(2);
        const unitMeterPrice = currentBaseRate * (parseFloat(w) / 650);
        const totalPrice = Math.round(unitMeterPrice * parseFloat(meters));

        state.cart.push({
          id: 'c_' + Date.now(),
          title: `Özel Kesim Bant (${sku})`,
          desc: `Genişlik: ${w}mm, Metraj: ${meters}m, ${currentSpliceLabel}`,
          qty: 1,
          unit: 'hat',
          unitPrice: totalPrice,
          image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBJhwVnmEkAv7dIdgZxkefDEhnA7l_wQqq01Tv9xIZIQ2fz_SLfah6mJpUXWrY4D_qiK3UEUcsB4NOZZcTdaJTklC69pPLMP-tvd_dDnEMwwKtPcyyBWeQRyYdwfF4fNum5jAdYaO-tTtit7COu_xxZ8gT_rurWZhfREPg658iwLK5XoIyTiGeLny-Yk0pvyNMbJ2ifhj5x8H7_I8l3-uTUBo8Aa-7-bzAwnE_HaAbrmZxZ8pPpbUbT'
        });

        renderCart();
        showToast('Özel kesim konveyör bandı teklif sepetinize eklendi!');
        window.location.hash = 'sepet';
      });
    }
  }

  // ==========================================
  // 4. RULO VALİDASYONU VE HESAPLAMA MOTORU
  // ==========================================
  function initRuloCalculator() {
    const selectD = document.getElementById('select-d');
    const selectMil = document.getElementById('select-mil');
    const inputL = document.getElementById('input-l');
    const inputA = document.getElementById('input-a');
    const inputSw = document.getElementById('input-sw');
    const inputFreze = document.getElementById('input-freze');
    const inputQty = document.getElementById('input-qty');
    const btnQtyMinus = document.getElementById('btn-qty-minus');
    const btnQtyPlus = document.getElementById('btn-qty-plus');

    const svgTextL = document.getElementById('svg-text-l');
    const svgTextA = document.getElementById('svg-text-a');
    const svgTextD = document.getElementById('svg-text-d');
    const svgTextMil = document.getElementById('svg-text-mil');

    const summaryD = document.getElementById('summary-d');
    const summaryMil = document.getElementById('summary-mil');
    const summaryL = document.getElementById('summary-l');
    const summaryA = document.getElementById('summary-a');
    const summaryMilUcu = document.getElementById('summary-mil-ucu');
    const summaryKaplama = document.getElementById('summary-kaplama');

    const validationBox = document.getElementById('validation-box');
    const skuBadge = document.getElementById('sku-badge');
    const badgeStatus = document.getElementById('badge-status');
    const priceUnit = document.getElementById('price-unit');
    const priceTotal = document.getElementById('price-total');
    const bulkDiscountNote = document.getElementById('bulk-discount-note');
    const addCartBtn = document.getElementById('btn-rulo-add-cart');
    const tabRulo = document.getElementById('tab-rulo');
    const tabTambur = document.getElementById('tab-tambur');

    if (!selectD || !inputL || !inputA) return;

    let isTamburMode = false;
    let currentMilCode = 'F14';
    let currentKaplamaExtra = 0;

    function setMode(tambur) {
      isTamburMode = tambur;
      if (tabRulo && tabTambur) {
        if (isTamburMode) {
          tabTambur.className = 'flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-mono font-bold bg-[#0284C7] text-white shadow-sm border border-[#0284C7] transition-all cursor-pointer';
          tabRulo.className = 'flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-mono font-medium text-slate-600 hover:bg-slate-50 border border-transparent transition-all cursor-pointer';
        } else {
          tabRulo.className = 'flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-mono font-bold bg-[#0284C7] text-white shadow-sm border border-[#0284C7] transition-all cursor-pointer';
          tabTambur.className = 'flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-mono font-medium text-slate-600 hover:bg-slate-50 border border-transparent transition-all cursor-pointer';
        }
      }

      if (isTamburMode) {
        selectD.innerHTML = `
          <option value="219" selected>Ø219 mm (Et Kalınlığı 8 mm)</option>
          <option value="273">Ø273 mm (Et Kalınlığı 10 mm)</option>
          <option value="324">Ø324 mm (Et Kalınlığı 12 mm)</option>
          <option value="406">Ø406 mm (Et Kalınlığı 14 mm)</option>
          <option value="508">Ø508 mm (Et Kalınlığı 16 mm Ağır Hizmet)</option>
          <option value="630">Ø630 mm (Et Kalınlığı 20 mm Maden Tipi)</option>
        `;
        selectMil.innerHTML = `
          <option value="50">Ø50 mm (Ç1040 Islah Çeliği)</option>
          <option value="60" selected>Ø60 mm (Ç1040 Islah Çeliği)</option>
          <option value="75">Ø75 mm (Ağır Hizmet Faturalı)</option>
          <option value="90">Ø90 mm (Ağır Hizmet Faturalı)</option>
          <option value="110">Ø110 mm (Maden / Agrega Tipi)</option>
          <option value="130">Ø130 mm (Konik Kilitli Montaj)</option>
        `;
        inputL.value = '950';
        inputA.value = '1150';
      } else {
        selectD.innerHTML = `
          <option value="60">Ø60 mm (Boru Et Kalınlığı 3 mm)</option>
          <option value="76">Ø76 mm (Boru Et Kalınlığı 3.2 mm)</option>
          <option value="89" selected>Ø89 mm (Boru Et Kalınlığı 3.65 mm)</option>
          <option value="108">Ø108 mm (Boru Et Kalınlığı 4 mm)</option>
          <option value="133">Ø133 mm (Boru Et Kalınlığı 4.5 mm)</option>
          <option value="159">Ø159 mm (Boru Et Kalınlığı 5 mm Ağır Hizmet)</option>
        `;
        selectMil.innerHTML = `
          <option value="20" selected>Ø20 mm (Ç1040 İmalat Çeliği)</option>
          <option value="25">Ø25 mm (Ç1040 İmalat Çeliği)</option>
          <option value="30">Ø30 mm (Ağır Hizmet Rulman Grubu)</option>
          <option value="35">Ø35 mm (Ağır Hizmet Rulman Grubu)</option>
        `;
        inputL.value = '315';
        inputA.value = '355';
      }
      updateConfig();
    }

    if (tabRulo) {
      tabRulo.addEventListener('click', () => {
        setMode(false);
        window.location.hash = 'rulo';
      });
    }
    if (tabTambur) {
      tabTambur.addEventListener('click', () => {
        setMode(true);
        window.location.hash = 'tambur';
      });
    }

    window.addEventListener('app:set-rulo-mode', (e) => {
      if (e && e.detail !== undefined) {
        setMode(!!e.detail.tambur);
      }
    });

    if (window.location.hash === '#tambur') {
      setMode(true);
    }

    function updateConfig() {
      const d = selectD.value;
      const mil = selectMil.value;
      const l = parseInt(inputL.value) || 0;
      const a = parseInt(inputA.value) || 0;
      const qty = parseInt(inputQty?.value) || 1;

      // Update SVG Labels
      if (svgTextD) svgTextD.textContent = `Ø D: ${d} mm`;
      if (svgTextMil) svgTextMil.textContent = `Ød:${mil}`;
      if (svgTextL) svgTextL.textContent = `L: ${l} mm`;
      if (svgTextA) svgTextA.textContent = `A: ${a} mm`;

      // Update Table
      if (summaryD) summaryD.textContent = `Ø${d} × 3.5 mm (DIN 2394)`;
      if (summaryMil) summaryMil.textContent = selectMil.options[selectMil.selectedIndex].text;
      if (summaryL) summaryL.textContent = `${l} mm`;
      if (summaryA) summaryA.textContent = `${a} mm`;

      // TOLERANS KONTROLÜ (A < L + 30)
      const diff = a - l;
      const isToleranceValid = diff >= 30;

      if (isToleranceValid) {
        if (validationBox) {
          validationBox.className = 'p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs font-mono text-emerald-800 transition-all';
          validationBox.innerHTML = `
            <div class="flex items-center gap-2">
              <span class="material-symbols-outlined text-[18px] text-emerald-600">check_circle</span>
              <span><strong>✓ Tolerans Kontrolü:</strong> Mil Boyu (A), Boru Boyundan (L) en az 30 mm uzun olmalıdır. (Mevcut Fark: <strong>${diff} mm</strong>) - İMALATA UYGUN</span>
            </div>
            <span class="bg-emerald-600 text-white text-[10px] uppercase font-bold px-2.5 py-0.5 rounded tracking-wide">Geçerli</span>
          `;
        }
        if (badgeStatus) {
          badgeStatus.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200';
          badgeStatus.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Üretilebilir / Onaylı`;
        }
        inputA.classList.remove('border-rose-400', 'bg-rose-50');

        // Butonu aktife al
        if (addCartBtn) {
          addCartBtn.disabled = false;
          addCartBtn.classList.remove('opacity-50', 'cursor-not-allowed', 'pointer-events-none');
        }
      } else {
        if (validationBox) {
          validationBox.className = 'p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center justify-between text-xs font-mono text-rose-800 transition-all';
          validationBox.innerHTML = `
            <div class="flex items-center gap-2">
              <span class="material-symbols-outlined text-[18px] text-rose-600">warning</span>
              <span><strong>⚠️ Tolerans Uyarısı:</strong> Mil Boyu (A) yetersiz! Boru boyundan en az 30 mm uzun olmalıdır. (Mevcut Fark: <strong>${diff} mm</strong>)</span>
            </div>
            <span class="bg-rose-600 text-white text-[10px] uppercase font-bold px-2.5 py-0.5 rounded tracking-wide">Hatalı Ölçü</span>
          `;
        }
        if (badgeStatus) {
          badgeStatus.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono font-semibold bg-rose-50 text-rose-700 border border-rose-200';
          badgeStatus.innerHTML = `<span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span> Tolerans Hatası`;
        }
        inputA.classList.add('border-rose-400', 'bg-rose-50');

        // Butonu pasife al (Kural 3 gereksinimi!)
        if (addCartBtn) {
          addCartBtn.disabled = true;
          addCartBtn.classList.add('opacity-50', 'cursor-not-allowed', 'pointer-events-none');
        }
      }

      // Dynamic SKU
      if (skuBadge) skuBadge.textContent = `DSN-ROL-D${d}-L${l}-A${a}-${currentMilCode}`;

      // Dynamic Price calculation
      const baseUnit = 280 + parseInt(d) * 2.1 + l * 0.55 + parseInt(mil) * 3 + currentKaplamaExtra;
      const finalUnit = Math.round(baseUnit);
      const discountRate = qty >= 25 ? 0.9 : 1.0;
      const total = Math.round(finalUnit * qty * discountRate);

      if (priceUnit) priceUnit.textContent = `${formatMoney(finalUnit)} / adet`;
      if (priceTotal) priceTotal.textContent = formatMoney(total);

      if (bulkDiscountNote) {
        if (qty >= 25) {
          bulkDiscountNote.textContent = `✨ %10 Proje İskontosu Uygulandı (${qty} adet)`;
          bulkDiscountNote.className = 'font-mono text-[11px] text-emerald-700 text-right font-semibold';
        } else {
          bulkDiscountNote.textContent = `✨ 25+ adette %10 proje iskontosu uygulanır.`;
          bulkDiscountNote.className = 'font-mono text-[11px] text-emerald-700 text-right';
        }
      }
    }

    // Mil ucu radio interaction
    const milCards = document.querySelectorAll('.mil-card');
    milCards.forEach(card => {
      card.addEventListener('click', () => {
        milCards.forEach(c => {
          c.classList.remove('border-2', 'border-[#0284C7]', 'bg-[#f0f9ff]');
          c.classList.add('border', 'border-slate-200', 'bg-white');
          const dot = c.querySelector('.radio-dot');
          if (dot) {
            dot.className = 'w-4 h-4 rounded-full border border-slate-300 bg-white flex items-center justify-center radio-dot';
            dot.innerHTML = '';
          }
          const radio = c.querySelector('input[type="radio"]');
          if (radio) radio.checked = false;
        });

        card.classList.add('border-2', 'border-[#0284C7]', 'bg-[#f0f9ff]');
        card.classList.remove('border-slate-200', 'bg-white');
        const activeDot = card.querySelector('.radio-dot');
        if (activeDot) {
          activeDot.className = 'w-4 h-4 rounded-full border-2 border-[#0284C7] bg-[#0284C7] flex items-center justify-center radio-dot';
          activeDot.innerHTML = '<div class="w-1.5 h-1.5 rounded-full bg-white"></div>';
        }
        const activeRadio = card.querySelector('input[type="radio"]');
        if (activeRadio) activeRadio.checked = true;

        const code = card.getAttribute('data-code') || 'F';
        const sw = inputSw?.value.trim() || '14';
        const freze = inputFreze?.value.trim() || '15';
        currentMilCode = `${code}${sw}`;
        if (summaryMilUcu) {
          summaryMilUcu.textContent = `${card.getAttribute('data-title')} (${sw} × ${freze} mm)`;
        }
        updateConfig();
      });
    });

    // Kaplama interaction
    const kaplamaCards = document.querySelectorAll('.kaplama-card');
    kaplamaCards.forEach(card => {
      card.addEventListener('click', () => {
        kaplamaCards.forEach(c => {
          c.classList.remove('border-2', 'border-[#0284C7]', 'bg-[#f0f9ff]');
          c.classList.add('border', 'border-slate-200', 'bg-white');
          const r = c.querySelector('input[type="radio"]');
          if (r) r.checked = false;
        });
        card.classList.add('border-2', 'border-[#0284C7]', 'bg-[#f0f9ff]');
        card.classList.remove('border-slate-200', 'bg-white');
        const r = card.querySelector('input[type="radio"]');
        if (r) r.checked = true;
        currentKaplamaExtra = parseInt(card.getAttribute('data-extra')) || 0;
        if (summaryKaplama) summaryKaplama.textContent = card.getAttribute('data-name');
        updateConfig();
      });
    });

    // Input listeners
    selectD.addEventListener('change', updateConfig);
    selectMil.addEventListener('change', updateConfig);
    inputL.addEventListener('input', updateConfig);
    inputA.addEventListener('input', updateConfig);

    if (inputSw) {
      inputSw.addEventListener('input', () => {
        const activeCard = document.querySelector('.mil-card.border-2');
        const code = activeCard ? activeCard.getAttribute('data-code') : 'F';
        currentMilCode = `${code}${inputSw.value.trim() || '14'}`;
        if (activeCard && summaryMilUcu) {
          summaryMilUcu.textContent = `${activeCard.getAttribute('data-title')} (${inputSw.value.trim() || '14'} × ${inputFreze?.value.trim() || '15'} mm)`;
        }
        updateConfig();
      });
    }

    if (btnQtyMinus && inputQty) {
      btnQtyMinus.addEventListener('click', () => {
        let q = parseInt(inputQty.value) || 1;
        if (q > 1) {
          inputQty.value = q - 1;
          updateConfig();
        }
      });
    }

    if (btnQtyPlus && inputQty) {
      btnQtyPlus.addEventListener('click', () => {
        let q = parseInt(inputQty.value) || 1;
        inputQty.value = q + 1;
        updateConfig();
      });
    }

    if (inputQty) {
      inputQty.addEventListener('input', () => {
        if (parseInt(inputQty.value) < 1) inputQty.value = 1;
        updateConfig();
      });
    }

    updateConfig();

    if (addCartBtn) {
      addCartBtn.addEventListener('click', () => {
        const d = selectD.value;
        const l = inputL.value;
        const a = inputA.value;
        const qty = parseInt(inputQty?.value) || 1;
        const sku = skuBadge ? skuBadge.textContent : (isTamburMode ? 'DSN-TMB' : 'DSN-ROL');
        const baseUnit = isTamburMode
          ? 3200 + parseInt(d) * 8.5 + parseInt(l) * 2.8 + currentKaplamaExtra * 2
          : 280 + parseInt(d) * 2.1 + parseInt(l) * 0.55 + 20 * 3 + currentKaplamaExtra;
        const finalUnit = Math.round(baseUnit);
        const itemTitle = isTamburMode ? `Özel İmalat Tahrik/Gergi Tamburu (${sku})` : `Özel İmalat Rulo (${sku})`;
        const itemDesc = isTamburMode ? `Gövde: Ø${d}mm, L: ${l}mm, Mil: ${a}mm, ${summaryKaplama ? summaryKaplama.textContent : 'Standart'}` : `Ø${d} mm, L: ${l}mm, A: ${a}mm, ${summaryKaplama ? summaryKaplama.textContent : 'Standart'}`;

        state.cart.push({
          id: 'c_' + Date.now(),
          title: itemTitle,
          desc: itemDesc,
          qty: qty,
          unit: 'ad',
          unitPrice: finalUnit,
          image: isTamburMode
            ? 'https://lh3.googleusercontent.com/aida-public/AB6AXuDFk0NuvpzHvs0XHGAM_11Z2V_ioDUVMIspsnKmKSYcVBu-PlYGKS6QE0UUNIn9vGkCMLO5uS4v7DwqhRRtCORbUShUUKQNpPiL-S6hXtinj1WPgl9DNJ_PtsnnXzmYGOH7KUkv4F_Wtwt_cMaCthL1FwNGxs6yftmxvyY0mpqgWQKxVA9ai-TZnPewvcttaZW6ZWQArdaXSJO3rdupYdpY5XYCa-X1YgoN96IcqN6DCegcW1HCgTtP'
            : 'https://lh3.googleusercontent.com/aida-public/AB6AXuBDXU98gVd288k6wB9YuZoN3Le3og3wl6oNnuHmH_8WLxRvmNK9Oh38GcNcnXjsEiEGx7jFSrFVnHSsYE9qyuuY2YDYYWZeKcESfG5tUsm87nVeMqr_VYTNH19UEFJB5VmASI_9pLJxdWdLfrAnJjyaO95ZwPPHidli-UhWrx4XAHqCdqOzm5jSPcxz_cRMygoCpy0tZissaGqOFT9c7Nnvj2nNM7yFpZ1YChw9IQ7pBimJYDgGM_3g'
        });

        renderCart();
        showToast(isTamburMode ? 'Özel imalat tambur teklif sepetinize eklendi!' : 'Özel imalat rulo teklif sepetinize eklendi!');
        window.location.hash = 'sepet';
      });
    }
  }

  // ==========================================
  // 5. SEPET TABLOSU VE PROFORMA HESAPLAMA MOTORU
  // ==========================================
  function renderCart() {
    saveCartToStorage();

    const dateEl = document.getElementById('print-proforma-date');
    if (dateEl) {
      dateEl.textContent = new Date().toLocaleDateString('tr-TR');
    }

    const tbody = document.getElementById('cart-table-body');
    const headerCartBadge = document.getElementById('header-cart-count');
    const tableBadge = document.getElementById('cart-item-count-badge');
    const subtotalEl = document.getElementById('proforma-subtotal') || document.getElementById('cart-subtotal');
    const discountEl = document.getElementById('proforma-discount');
    const netEl = document.getElementById('proforma-net');
    const vatEl = document.getElementById('proforma-vat') || document.getElementById('cart-tax');
    const totalEl = document.getElementById('proforma-total') || document.getElementById('cart-grand-total');
    const emptyMsg = document.getElementById('cart-empty-msg');
    const cartContent = document.getElementById('cart-content');

    const totalKalem = state.cart.length;
    if (headerCartBadge) headerCartBadge.textContent = `Teklif Sepetim (${totalKalem} Kalem)`;
    const mobileCartBadge = document.getElementById('mobile-cart-label');
    if (mobileCartBadge) mobileCartBadge.textContent = `Teklif Sepetim (${totalKalem} Kalem)`;
    if (tableBadge) tableBadge.textContent = `Toplam ${totalKalem} Kalem`;

    const tableWrapper = document.getElementById('cart-table-wrapper');

    if (totalKalem === 0) {
      if (emptyMsg) emptyMsg.classList.remove('hidden');
      if (tableWrapper) tableWrapper.classList.add('hidden');
      if (tbody) tbody.innerHTML = '';
      if (subtotalEl) subtotalEl.textContent = formatMoney(0);
      if (discountEl) discountEl.textContent = `- ${formatMoney(0)}`;
      if (netEl) netEl.textContent = formatMoney(0);
      if (vatEl) vatEl.textContent = formatMoney(0);
      if (totalEl) totalEl.textContent = formatMoney(0);
      return;
    }

    if (emptyMsg) emptyMsg.classList.add('hidden');
    if (tableWrapper) tableWrapper.classList.remove('hidden');

    if (!tbody) return;

    let subtotal = 0;
    tbody.innerHTML = '';

    state.cart.forEach((item, index) => {
      const rowTotal = item.qty * item.unitPrice;
      subtotal += rowTotal;
      const rowNum = String(index + 1).padStart(2, '0');

      const tr = document.createElement('tr');
      tr.className = 'group hover:bg-slate-50/70 transition-colors';
      tr.innerHTML = `
        <td class="py-4 pl-2 font-mono text-slate-400 text-xs">${rowNum}</td>
        <td class="py-4 pr-4">
          <div class="flex gap-3.5 items-center">
            <div class="w-12 h-12 bg-slate-100 rounded border border-[#CBD5E1] flex items-center justify-center shrink-0 overflow-hidden">
              <img alt="${item.title}" class="w-full h-full object-cover" src="${item.image}" />
            </div>
            <div class="flex flex-col">
              <span class="font-semibold text-slate-900 group-hover:text-[#0284C7] transition-colors">${item.title}</span>
              <span class="text-xs text-slate-500">${item.desc}</span>
            </div>
          </div>
        </td>
        <td class="py-4 text-center">
          <div class="inline-flex items-center bg-white border border-slate-300 rounded-lg shadow-2xs text-xs font-mono overflow-hidden">
            <button class="cart-minus-btn px-2.5 py-1 text-slate-600 hover:bg-slate-100 hover:text-slate-900 font-bold transition-all cursor-pointer active:scale-90 select-none" data-id="${item.id}">-</button>
            <span class="px-2.5 py-1 text-center min-w-[56px] font-semibold border-x border-slate-200 text-slate-800 bg-slate-50/50">${item.qty} ${item.unit}</span>
            <button class="cart-plus-btn px-2.5 py-1 text-slate-600 hover:bg-slate-100 hover:text-slate-900 font-bold transition-all cursor-pointer active:scale-90 select-none" data-id="${item.id}">+</button>
          </div>
        </td>
        <td class="py-4 text-right pr-3 font-mono text-slate-700 text-xs">${formatMoney(item.unitPrice)}</td>
        <td class="py-4 text-right pr-3 font-mono font-bold text-slate-900 text-xs">${formatMoney(rowTotal)}</td>
        <td class="py-4 text-right">
          <button class="cart-delete-btn text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg p-1.5 transition-all cursor-pointer active:scale-90 inline-flex items-center justify-center" data-id="${item.id}" title="Sil">
            <span class="material-symbols-outlined text-[18px]">delete</span>
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // Proforma Calculations (15% B2B Kurumsal İskonto)
    const discount = subtotal * 0.15;
    const net = subtotal - discount;
    const vat = net * 0.20; // 20% KDV
    const generalTotal = net + vat;

    if (subtotalEl) subtotalEl.textContent = formatMoney(subtotal);
    if (discountEl) discountEl.textContent = `- ${formatMoney(discount)}`;
    if (netEl) netEl.textContent = formatMoney(net);
    if (vatEl) vatEl.textContent = formatMoney(vat);
    if (totalEl) totalEl.textContent = formatMoney(generalTotal);
  }

  function initCartEvents() {
    document.addEventListener('click', e => {
      // Plus button
      const plusBtn = e.target.closest('.cart-plus-btn');
      if (plusBtn) {
        const id = plusBtn.getAttribute('data-id');
        const item = state.cart.find(i => i.id === id);
        if (item) {
          item.qty += item.unit === 'm' ? 10 : 1;
          renderCart();
        }
        return;
      }

      // Minus button
      const minusBtn = e.target.closest('.cart-minus-btn');
      if (minusBtn) {
        const id = minusBtn.getAttribute('data-id');
        const item = state.cart.find(i => i.id === id);
        if (item) {
          const step = item.unit === 'm' ? 10 : 1;
          if (item.qty > step) {
            item.qty -= step;
          }
          renderCart();
        }
        return;
      }

      // Delete button
      const deleteBtn = e.target.closest('.cart-delete-btn');
      if (deleteBtn) {
        const id = deleteBtn.getAttribute('data-id');
        state.cart = state.cart.filter(i => i.id !== id);
        renderCart();
        showToast('Kalem sepetten silindi.');
        return;
      }

      // Clear cart button
      const clearBtn = e.target.closest('#btn-clear-cart');
      if (clearBtn) {
        state.cart = [];
        renderCart();
        showToast('Teklif sepeti temizlendi.');
        return;
      }

      // Send Quote to Representative via WhatsApp
      const repBtn = e.target.closest('#btn-send-rep');
      if (repBtn) {
        if (state.cart.length === 0) {
          showToast('Sepetiniz boş. Lütfen önce teklif kalemi ekleyiniz.', 'error');
          return;
        }

        let subtotal = 0;
        state.cart.forEach(item => {
          subtotal += item.qty * item.unitPrice;
        });
        const discount = subtotal * 0.15;
        const net = subtotal - discount;
        const vat = net * 0.20;
        const generalTotal = net + vat;

        const formatWAPrice = val => {
          if (state.currency === 'USD') {
            return '$ ' + (val / state.usdRate).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
          }
          return '₺ ' + val.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        };

        let msg = `*DESAN MAKİNA - RESMİ B2B TEKLİF TALEBİ*\n`;
        msg += `----------------------------------------\n`;
        msg += `*Firma:* Ods Madencilik ve Lojistik A.Ş.\n`;
        msg += `*Yetkili:* Ahmet Yılmaz (Satınalma Md.)\n`;
        msg += `*Tarih:* ${new Date().toLocaleDateString('tr-TR')} ${new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}\n`;
        msg += `----------------------------------------\n`;
        msg += `*TALEP EDİLEN KALEMLER (${state.cart.length} Kalem):*\n\n`;

        state.cart.forEach((item, idx) => {
          const rowTotal = item.qty * item.unitPrice;
          msg += `${idx + 1}. *${item.title}*\n`;
          if (item.desc) msg += `   Detay: ${item.desc}\n`;
          msg += `   Miktar: ${item.qty} ${item.unit}\n`;
          msg += `   Birim Fiyat: ${formatWAPrice(item.unitPrice)} | Tutar: ${formatWAPrice(rowTotal)}\n\n`;
        });

        msg += `----------------------------------------\n`;
        msg += `*Ara Toplam:* ${formatWAPrice(subtotal)}\n`;
        msg += `*B2B Kurumsal İskonto (%15):* -${formatWAPrice(discount)}\n`;
        msg += `*Net Tutar:* ${formatWAPrice(net)}\n`;
        msg += `*KDV (%20):* ${formatWAPrice(vat)}\n`;
        msg += `*GENEL TOPLAM:* ${formatWAPrice(generalTotal)}\n`;
        msg += `----------------------------------------\n`;
        msg += `Bu teklif talebimizin onaylanarak tarafımıza resmi proforma faturası ve teslimat süresi bildirilmesini rica ederiz.`;

        const waUrl = `https://wa.me/905327075281?text=${encodeURIComponent(msg)}`;
        window.open(waUrl, '_blank');
        showToast('Resmi teklif WhatsApp satış hattına aktarılıyor...', 'success');
        return;
      }

      // General Checkout button
      const checkoutBtn = e.target.closest('#btn-checkout');
      if (checkoutBtn) {
        if (state.cart.length === 0) {
          showToast('Sepetiniz boş. Lütfen önce ürün ekleyiniz.', 'error');
          return;
        }
        showToast('Resmi Teklif ve Satın Alma Talebiniz Alındı! Satış mühendisimiz 30 dk içinde dönecektir.', 'success');
        return;
      }

      // Catalog "Teklife Ekle" buttons
      const addCatalogBtn = e.target.closest('[data-add-catalog]');
      if (addCatalogBtn) {
        const title = addCatalogBtn.getAttribute('data-title');
        const price = parseFloat(addCatalogBtn.getAttribute('data-price')) || 1000;
        const desc = addCatalogBtn.getAttribute('data-desc') || 'Standart konveyör parçası';

        state.cart.push({
          id: 'c_' + Date.now(),
          title: title,
          desc: desc,
          qty: 1,
          unit: 'ad',
          unitPrice: price,
          image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA_Ktx4OFsRmW-hNuz3khP8M5BfXI_tPKqs3V4uA4KJteGJ0LY4CFPh8SwSse8-slw5qgG-2GJVKWIVANMgvUvYv0VnjQ5DmXnJDFlwnOIRjVS9OaytYxsACV12yNyHOQ0kwkQD0TJvpvCFHF1SzFk6lN7FyCksZyQQZLlhMDfdO2I7r-j7nhlU1FJ61jIZ33Erz_jwyui8FzjHAxulJC2J5-UDX5Kw4tMm3lxYpF4S4jNFQRupoVcv'
        });

        renderCart();
        showToast(`${title} teklif sepetine eklendi!`);
        return;
      }

      // PDF Download Proforma button
      const pdfBtn = e.target.closest('#btn-download-proforma, #btn-download-pdf');
      if (pdfBtn) {
        showToast('Kaşeli Resmi Proforma PDF hazırlanıyor...', 'success');
        setTimeout(() => {
          window.print();
        }, 600);
        return;
      }

      // Currency toggle buttons
      const tryBtn = e.target.closest('#btn-curr-try, #btn-curr-tl, #btn-curr-tl-mobile');
      const usdBtn = e.target.closest('#btn-curr-usd, #btn-curr-usd-mobile');
      const eurBtn = e.target.closest('#btn-curr-eur');
      if (tryBtn || usdBtn || eurBtn) {
        if (tryBtn) state.currency = 'TL';
        else if (usdBtn) state.currency = 'USD';
        else if (eurBtn) state.currency = 'USD'; // EUR mapped similarly for demo

        const isTL = state.currency === 'TL';

        // Update desktop & mobile button styles
        const tryEls = document.querySelectorAll('#btn-curr-try, #btn-curr-tl, #btn-curr-tl-mobile');
        const usdEls = document.querySelectorAll('#btn-curr-usd, #btn-curr-usd-mobile');
        const eurEl = document.getElementById('btn-curr-eur');

        tryEls.forEach(el => {
          if (isTL) {
            el.className = el.id.includes('mobile') 
              ? 'px-3 py-1 bg-[#0284c7] text-white font-bold tracking-wider cursor-pointer active:scale-95 transition-all'
              : 'px-2.5 py-0.5 bg-[#0284c7] text-white font-bold tracking-wider cursor-pointer active:scale-95 transition-all';
          } else {
            el.className = el.id.includes('mobile')
              ? 'px-3 py-1 text-slate-600 hover:bg-slate-100 font-medium cursor-pointer active:scale-95 transition-all'
              : 'px-2.5 py-0.5 text-slate-600 hover:bg-slate-100 transition-all font-medium cursor-pointer active:scale-95';
          }
        });

        usdEls.forEach(el => {
          if (!isTL) {
            el.className = el.id.includes('mobile')
              ? 'px-3 py-1 bg-[#0284c7] text-white font-bold tracking-wider cursor-pointer active:scale-95 transition-all'
              : 'px-2.5 py-0.5 bg-[#0284c7] text-white font-bold tracking-wider cursor-pointer active:scale-95 transition-all';
          } else {
            el.className = el.id.includes('mobile')
              ? 'px-3 py-1 text-slate-600 hover:bg-slate-100 font-medium cursor-pointer active:scale-95 transition-all'
              : 'px-2.5 py-0.5 text-slate-600 hover:bg-slate-100 transition-all font-medium cursor-pointer active:scale-95';
          }
        });

        if (eurEl) {
          eurEl.className = 'px-2.5 py-0.5 text-slate-600 hover:bg-slate-100 transition-all font-medium cursor-pointer active:scale-95';
        }

        renderCart();
        initHomeCalculator();
        initBantCalculator();
        initRuloCalculator();
      }
    });
  }

  // ==========================================
  // INITIALIZATION ON DOM READY
  // ==========================================
  document.addEventListener('DOMContentLoaded', () => {
    initRouter();
    initMobileMenu();
    initHomeCalculator();
    initBantCalculator();
    initRuloCalculator();
    initCartEvents();
    renderCart();
  });

})();
